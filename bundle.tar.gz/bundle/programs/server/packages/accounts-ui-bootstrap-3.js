(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['accounts-ui-bootstrap-3'] = {};

})();

//# sourceMappingURL=accounts-ui-bootstrap-3.js.map
